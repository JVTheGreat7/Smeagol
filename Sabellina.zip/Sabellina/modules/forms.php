<?php
// Database credentials
$servername = "localhost";  // usually "localhost" for local setup
$username = "root";         // replace with your MySQL username
$password = "";             // replace with your MySQL password
$dbname = "user_form_db";   // database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and collect form data
    $city = mysqli_real_escape_string($conn, $_POST['city']);
    $username = mysqli_real_escape_string($conn, $_POST['name']);
    $age = (int)$_POST['age'];
    $date = mysqli_real_escape_string($conn, $_POST['date']);

    // SQL query to insert data into the database
    $sql = "INSERT INTO users (city, username, age, date) VALUES ('$city', '$username', $age, '$date')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo "<h2>Form Submitted Successfully!</h2>";
        echo "City: " . htmlspecialchars($city) . "<br>";
        echo "Name: " . htmlspecialchars($username) . "<br>";
        echo "Age: " . htmlspecialchars($age) . "<br>";
        echo "Date: " . htmlspecialchars($date) . "<br><br>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Form</title>
</head>
<body>

<h1>Users</h1>

<form method="POST" action="">
    <label>City:</label>
    <select name="city" required>
        <option value="">-- Select City --</option>
        <option value="London">London</option>
        <option value="Paris">Paris</option>
        <option value="Tokyo">Tokyo</option>
    </select>
    <br><br>

    <label>Name:</label>
    <input type="text" name="name" required>
    <br><br>

    <label>Age:</label>
    <input type="number" name="age" min="0" required>
    <br><br>

    <label>Date:</label>
    <input type="date" name="date" required>
    <br><br>

    <button type="submit">Submit</button>
</form>

</body>
</html>
