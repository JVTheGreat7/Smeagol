<table class="data table">
    <thead>
        <tr>
            <th>ID</th>
            <th>City</th>
            <th>Username</th>
            <th>Age</th>
            
    </thead>
    <tbody>
        <?php
        $conn = new mysqli('localhost', 'root', '', 'user_form_db');
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "SELECT id, city, username, age FROM users";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . htmlspecialchars($row['id']) . "</td>
                        <td>" . htmlspecialchars($row['city']) . "</td>
                        <td>" . htmlspecialchars($row['username']) . "</td>
                        <td>" . htmlspecialchars($row['age']) . "</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No users found</td></tr>";
        }
        $conn->close();
        ?>
    </tbody>
</table>